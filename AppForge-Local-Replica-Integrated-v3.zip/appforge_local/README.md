# AppForge Local

A locally hosted PWA for app trend discovery, competitor-gap analysis, AI-assisted original app source generation, and local project tracking. It does not depend on hosted app builders.

## Requirements
- Python 3.10+ (no pip dependencies for the server)
- Optional: Ollama or another local OpenAI-compatible chat-completions endpoint for analysis and generation
- Optional Android packaging: Node.js/npm, Java JDK, Android SDK, Gradle, and a Capacitor-compatible project

## Run
1. Extract this folder on your computer or Android device with a Python environment (Termux works for the web UI).
2. Run `python server.py`.
3. Open `http://127.0.0.1:8787` in your browser. On Android, install/run Python in Termux and open the same address in Chrome.
4. For a phone on the same trusted Wi-Fi, set `APPFORGE_HOST=0.0.0.0` before starting; use the computer's LAN IP in the phone browser. This exposes an unauthenticated local service to that LAN, so use only on a trusted network and stop it when finished.
5. Optional local AI: run Ollama, pull a coding-capable model, then open Local AI settings. Default URL is `http://127.0.0.1:8080/v1`, matching a common local OpenAI-compatible server setup. Change the endpoint/model in Settings to match your actual server. If using Ollama, its default URL is usually `http://127.0.0.1:11434/v1`.

## Features
- Apple top-free RSS snapshot by country/region (requires internet). This is not a download-volume feed or a viral-growth guarantee.
- Official Google Play and Apple chart links for manual discovery. Google Play charts are not scraped because unofficial scraping can break and misrepresent ranking data.
- AI gap analysis grounded in the prompt and evidence you provide. It cannot infer private competitor metrics.
- AI generation of original files into `workspace/<project>/`.
- Static project-file checks and a PWA shell with offline caching for the interface.

## APK limitations
A PWA is not automatically a native Android APK. APK packaging needs a valid Android/Capacitor project and a configured Android build environment. The server's APK command only runs a known sequence (`npm run build`, `npx cap sync android`, `./gradlew assembleDebug`) when a package.json is present. A successful source generation is not the same as a production-ready release: review code, add tests, check permissions/privacy, test on real devices, sign a release build, and complete Google Play's current policy and listing requirements.

## Safety
- The server binds to `127.0.0.1` by default.
- Do not expose it to the public internet: it has no login/authentication.
- Keep secrets out of prompts and generated projects.
- The system is intended to analyze public-facing app features and build an original implementation, not decompile/copy competitor code or branding.
- Publishing, developer account fees, Play Store review, ad network approval, payments/tax compliance, and revenue are not automated or guaranteed.

## Project structure
- `server.py` — standard-library local API and static server
- `static/` — PWA interface, styles, client logic, manifest, service worker, icon
- `workspace/` — generated project files
- `config.json` — local model endpoint settings


## Advanced self-evolution and optional open-source integrations
- **Self-evolution page:** saves owner feedback locally and asks the configured model for an evidence-aware prioritized improvement roadmap. It does not self-edit core files or run arbitrary shell commands.
- **Integration catalog:** links optional open-source projects for app intelligence and coding-agent workflows. These are recommendations/adapters, not bundled source code.
- **AppStoreCat:** https://github.com/appstorecat/appstorecat — investigate as a separate app-intelligence service. Review its current license, data-source terms, setup and resource footprint before deployment.
- **OpenHands:** https://github.com/OpenHands/OpenHands — powerful self-hosted coding agent/automation option; likely too heavy for a low-resource Android phone. Use a sandbox if evaluating.
- **Aider:** https://github.com/Aider-AI/aider — Git-aware coding assistant for a controlled edit/test loop.
- **OpenCode:** https://github.com/anomalyco/opencode — alternative open-source coding agent; verify current license and runtime requirements before adoption.

### Suggested staged integration
1. Keep AppForge as the local control plane and use AppStoreCat only as a separate research service after reviewing its deployment requirements.
2. Add an adapter that imports app records/reviews with source URL and collection timestamp; do not treat rankings as proof of revenue or virality.
3. Use Aider or OpenHands behind an isolated project workspace for code edits, tests and repair loops. Never grant an agent unrestricted access to your personal files or credentials.
4. Add regression tests, a Git checkpoint before every accepted change, explicit approval gates, and rollback before allowing any agent to write code.
5. Keep store publishing, signing keys, payments, and financial actions owner-approved.

This upgrade improves the workflow but does not itself install the external repositories, scrape all Google Play data, compile every generated app, or publish apps automatically.

## Advanced audit upgrade (2026-10)

### Research pipeline
- `GET /api/research/search?term=...&region=in` uses Apple's public iTunes Search API, records source and collection timestamp in SQLite, and labels results as search relevance (not chart ranking).
- `POST /api/research/snapshot` and `GET /api/trends?region=in` collect timestamped Apple top-free chart snapshots with exponential retries. Ranking history is available at `/api/research/history?app_id=...`; history accumulates only after repeated collections.
- `GET /api/research/reviews?app_id=<numeric-id>&region=in` attempts Apple's public customer-review RSS. RSS availability varies; this is best-effort, not a complete reviews API. The endpoint returns rating counts and average when reviews are available.
- SQLite lives in `state/appforge.db`. AppForge does not invent Google Play rankings; Google Play is still linked for manual discovery and requires a separately approved, reliable data source for automated history/reviews.

### Android scaffold, tests and repair
- For an existing generated project with `index.html`, use **Prepare Android** to write `package.json`, `capacitor.config.json`, and a smoke test. This is a scaffold, not a compiled APK.
- Use **Run tests** for required-file checks, JSON parsing, Node JavaScript syntax checks, and npm tests when configured. Reports are saved under `workspace/<project>/test-reports/`.
- **Approved AI repair** makes one bounded local-model patch attempt after an explicit confirmation and Git checkpoint. It only edits existing, selected files; if available checks fail, tracked files are restored to the checkpoint. Review the diff and logs. This is not a guarantee of functional correctness.
- APK success is returned only when Gradle exits successfully and a non-empty APK artifact exists. Actual builds still require Node/npm, Java, Android SDK, Android platform files and a working network/dependency cache.

### Controlled evolution and open-source coding adapter
- Git checkpoint and rollback actions are available per project. Rollback restores tracked files to the latest commit and intentionally preserves untracked files.
- Optional Aider adapter: `POST /api/aider/run` requires `approved: true`, a project slug, and a focused prompt. It checkpoints first and runs only in that project directory. Aider is not bundled or installed automatically. Review upstream license/dependencies and install it in a dedicated virtual environment before use. The catalog lists its Apache-2.0 license, shown by the upstream GitHub repository; re-check `LICENSE.txt` in the exact revision before deployment before deployment.
- Local AI repair and Aider require a compatible model endpoint. The app does not allow an agent to access arbitrary project paths through these endpoints.

### Monetization, launch and analytics
- `/api/launch` stores a local monetization/region/privacy configuration and returns a Play Store readiness checklist.
- `/api/track` and `/api/analytics?project=...` store/report manually submitted local events. They do not automatically instrument apps or send analytics to an external provider.
- No real billing, ad serving, conversion SDK, Play Console submission, release signing, automatic publishing, or revenue generation is implemented. Those integrations require provider credentials, policy review, and explicit owner actions.

### Run tests
`python -m unittest tests.test_advanced -v`

The app binds to localhost by default and has no authentication. Do not expose it to the public internet. Public research calls need internet access; data collection is source-dependent and must comply with the source's terms.

## Replica Skill workflow adapter
- Upstream: https://github.com/Jakeschincariol/replica-skill (MIT, per its upstream LICENSE/README)
- AppForge exposes an 11-stage local workflow via **Replica workflow** in the dashboard and `GET /api/replica/workflows` / `POST /api/replica/run`.
- Starts with Reconnaissance, then architecture, design, build, backend plan, tests, gap review, review-based differentiation, new branding, store listing, and release preflight.
- Artifacts are stored under `workspace/<project>/replica/`; AI calls use the configured local OpenAI-compatible model. Every stage requires explicit approval. Build output is limited to six app filenames and an existing project app file must be checkpointed with Git before it can be overwritten.
- This is an AppForge-native adapter, not the original upstream skill pack: official upstream SKILL.md files/tools are not bundled in this archive. See `integrations/replica-skill/README.md` for the boundary and official install instructions.
- This workflow does not automatically browse competitor apps, compile APKs, deploy, submit to Google Play, or generate revenue. Review the generated artifacts and run tests.
