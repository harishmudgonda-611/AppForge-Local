# Replica Skill integration for AppForge Local

Upstream project: https://github.com/Jakeschincariol/replica-skill

The upstream README documents an MIT-licensed 11-skill workflow for app reconnaissance, architecture, design, building, backend planning, testing, feature-gap review, review-led differentiation, branding, store listing and deployment preparation.

AppForge includes a **native local workflow adapter** for these stages at `/api/replica/workflows` and `/api/replica/run`, surfaced in the PWA as **Replica workflow**. Outputs are saved under `workspace/<project>/replica/`; the Build stage is limited to six PWA filenames and requests a Git checkpoint before overwriting existing app files. Each stage must be explicitly approved.

This archive does **not** contain copied upstream `SKILL.md` files or upstream Python utilities. The AppForge adapter is independently authored from the publicly documented workflow and has its own tests. The upstream repo's stated license is MIT; preserve upstream copyright/license notices if you separately obtain and redistribute upstream files.

To use the official skill pack with Claude Code, follow the upstream instructions and current repository README. The upstream install command currently documented there is:

```text
/plugin marketplace add Jakeschincariol/replica-skill
/plugin install replica-skill@replica-skill
```

Safety notes: use public product pages and user-provided evidence only; never decompile the target app, copy proprietary code/assets/branding, bypass logins/paywalls, invent review statistics, or treat the workflow output as legal advice. Deployment and store submission remain owner-controlled.
