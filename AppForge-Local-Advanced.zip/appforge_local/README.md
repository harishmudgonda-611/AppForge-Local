# AppForge Local

A locally hosted PWA for app trend discovery, competitor-gap analysis, AI-assisted original app source generation, and local project tracking. It does not depend on hosted app builders.

## Requirements
- Python 3.10+ (no pip dependencies for the server)
- Optional: Ollama or another local OpenAI-compatible chat-completions endpoint for analysis and generation
- Optional Android packaging: Node.js/npm, Java JDK, Android SDK, Gradle, and a Capacitor-compatible project

## Run
1. Extract this folder on your computer or Android device with a Python environment (Termux works for the web UI).
2. Run `python server.py`.
3. Open `http://127.0.0.1:8787` in your browser. On Android, install/run Python in Termux and open the same address in Chrome.
4. For a phone on the same trusted Wi-Fi, set `APPFORGE_HOST=0.0.0.0` before starting; use the computer's LAN IP in the phone browser. This exposes an unauthenticated local service to that LAN, so use only on a trusted network and stop it when finished.
5. Optional local AI: run Ollama, pull a coding-capable model, then open Local AI settings. Default URL is `http://127.0.0.1:8080/v1`, matching a common local OpenAI-compatible server setup. Change the endpoint/model in Settings to match your actual server. If using Ollama, its default URL is usually `http://127.0.0.1:11434/v1`.

## Features
- Apple top-free RSS snapshot by country/region (requires internet). This is not a download-volume feed or a viral-growth guarantee.
- Official Google Play and Apple chart links for manual discovery. Google Play charts are not scraped because unofficial scraping can break and misrepresent ranking data.
- AI gap analysis grounded in the prompt and evidence you provide. It cannot infer private competitor metrics.
- AI generation of original files into `workspace/<project>/`.
- Static project-file checks and a PWA shell with offline caching for the interface.

## APK limitations
A PWA is not automatically a native Android APK. APK packaging needs a valid Android/Capacitor project and a configured Android build environment. The server's APK command only runs a known sequence (`npm run build`, `npx cap sync android`, `./gradlew assembleDebug`) when a package.json is present. A successful source generation is not the same as a production-ready release: review code, add tests, check permissions/privacy, test on real devices, sign a release build, and complete Google Play's current policy and listing requirements.

## Safety
- The server binds to `127.0.0.1` by default.
- Do not expose it to the public internet: it has no login/authentication.
- Keep secrets out of prompts and generated projects.
- The system is intended to analyze public-facing app features and build an original implementation, not decompile/copy competitor code or branding.
- Publishing, developer account fees, Play Store review, ad network approval, payments/tax compliance, and revenue are not automated or guaranteed.

## Project structure
- `server.py` — standard-library local API and static server
- `static/` — PWA interface, styles, client logic, manifest, service worker, icon
- `workspace/` — generated project files
- `config.json` — local model endpoint settings


## Advanced self-evolution and optional open-source integrations
- **Self-evolution page:** saves owner feedback locally and asks the configured model for an evidence-aware prioritized improvement roadmap. It does not self-edit core files or run arbitrary shell commands.
- **Integration catalog:** links optional open-source projects for app intelligence and coding-agent workflows. These are recommendations/adapters, not bundled source code.
- **AppStoreCat:** https://github.com/appstorecat/appstorecat — investigate as a separate app-intelligence service. Review its current license, data-source terms, setup and resource footprint before deployment.
- **OpenHands:** https://github.com/OpenHands/OpenHands — powerful self-hosted coding agent/automation option; likely too heavy for a low-resource Android phone. Use a sandbox if evaluating.
- **Aider:** https://github.com/Aider-AI/aider — Git-aware coding assistant for a controlled edit/test loop.
- **OpenCode:** https://github.com/anomalyco/opencode — alternative open-source coding agent; verify current license and runtime requirements before adoption.

### Suggested staged integration
1. Keep AppForge as the local control plane and use AppStoreCat only as a separate research service after reviewing its deployment requirements.
2. Add an adapter that imports app records/reviews with source URL and collection timestamp; do not treat rankings as proof of revenue or virality.
3. Use Aider or OpenHands behind an isolated project workspace for code edits, tests and repair loops. Never grant an agent unrestricted access to your personal files or credentials.
4. Add regression tests, a Git checkpoint before every accepted change, explicit approval gates, and rollback before allowing any agent to write code.
5. Keep store publishing, signing keys, payments, and financial actions owner-approved.

This upgrade improves the workflow but does not itself install the external repositories, scrape all Google Play data, compile every generated app, or publish apps automatically.
